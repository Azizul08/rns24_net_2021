<?php 
$redirect="https://www.google.com/";
?>